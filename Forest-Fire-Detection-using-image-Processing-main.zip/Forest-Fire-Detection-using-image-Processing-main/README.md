# Forest-Fire-Detection-using-image-Processing
In the Project Code Folder file named project.m contains the code of matlab one can upload the videos available in the dataset folder and run the project.m code in matlab to get the output
## [Demo](https://drive.google.com/file/d/13zwls4ytnmfD2b10anGv0cIhwgQBA1Fz/view?usp=sharing)
